<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
<header class="sticky-top">
        <nav class="navbar navbar-expand-sm navbar-light sticky">
            <div class="container-fluid">

                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">Home</a>
                        </li>
                        <?php 
                            session_start();
                            if(!empty($_COOKIE['id'])){
                                if($_COOKIE['level']==2){
                                    echo '<li class="nav-item">
                                            <a class="nav-link active" href="manager.php">Manager</a>
                                        </li>';
                                }

                                    echo '<li class="nav-item">
                                        <a class="nav-link " href="manager-post.php">Manager post</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link " href="logout.php">Logout</a>
                                    </li>
                                    
                                    ';
                            }
                            else{
                                echo '<li class="nav-item">
                                        <a class="nav-link " href="login.php">Login</a>
                                    </li>';
                            }

                        ?>

                    </ul>
                </div>
            </div>
        </nav>
    </header>
<div>

            <span>
            <form method="GET" >
                <input type="text" placeholder="Username" name="search_user">
                <button class="btn btn-primary">Tìm kiếm</button>
            </form>
            </span>
            <br>
        </div>
        <table class="table table-hover table-bordered table-striped text-center">
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Level</th>
                    <th></th>
                </tr>
                <?php
                    $connect=new mysqli("localhost","root","","level2");
                    mysqli_set_charset($connect, "utf8");
                    if($connect->connect_error){
                        var_dump($connect->connect_error);
                        die();
                    }
                    if(isset($_GET['search_user']) && $_GET['search_user']!=''){
                        $search_user=$_GET['search_user'];
                        $query="select * from users where username like '%$search_user%'";
                    }
                    else{
                        $query="select * from users";
                    }
                    $result=$connect->query($query);



                    while($data = $result->fetch_assoc()) {

                        echo '
                            <tr>
                            <td>'.$data['id'].'</td>
                            <td>'.$data['username'].'</td>
                            <td>'.$data['password'].'</td>
                            <td>'.$data['level'].'</td>
                            <td><a href="?delete_id='.$data['id'].'"><button class="btn btn-danger">Xóa</button></a>
                                <span><a href="?modify_id='.$data['id'].'"><button class="btn btn-primary">Chỉnh sửa</button></a></span>
                                </td>
                            </tr>
                        ';
                    }
                    $connect->close();
                ?>
        </table>
        <div class="container">
            <?php
                $connect=new mysqli("localhost","root","","level2");
                mysqli_set_charset($connect, "utf8");
                if($connect->connect_error){
                var_dump($connect->connect_error);
                    die();
                }
                if(isset($_GET['modify_id'])){

                    $modify_id=$_GET['modify_id'];
                    $modify_query="select * from users where id= '$modify_id'" ;
                    $result=$connect->query($modify_query);

                    while($data = $result->fetch_assoc()) {

                    echo '
                        <form class="form-inline" action="update.php?update_id='.$_GET['modify_id'].'" method="POST">
                            <label for="username" >Username</label>
                            <input type="username" class="form-control" id="username" name="username" value='.$data['username'].'>
                            <label for="passord">Password</label>
                            <input type="text" class="form-control" id="passord" name="password" value="'.$data['password'].'">
                            <label for "level">Level</label>
                            <select class="form-control" id="level" name="level">
                                <option value="2" >Admin</option>
                                <option value="1" >Post manager</option>
                                <option value="0" >User</option>
                            </select>
                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                        </form>
                        ';
                    }
                    $connect->close();
                }

                if(isset($_GET['delete_id'])){
                    if($_COOKIE['level']!=2){
                        echo "<script>alert('nope')</script>";
                    }
                    else{
                        $delete_id=$_GET['delete_id'];
                        $delete_query="delete from users where id='$delete_id'";
                        $connect->query($delete_query);
                        $connect->close();
                            echo "<script>window.location.href='./manager.php';</script>";
                    }
                }




            ?>

        </div>
    </div>
</body>
</html>
<?php

    if($_COOKIE['level']!=2){
        echo "<script>window.location.href='./index.php';</script>";
    }
?>
