<?php

if($_POST['username']!='' && $_POST['password']!=''){   
    $connect=new mysqli("localhost","root","","level2");
    mysqli_set_charset($connect, "utf8");
    if($connect->connect_error){
        var_dump($connect->connect_error);
        die();
    }
    $update_id=$_GET['update_id'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $level=$_POST['level'];
    $update_query="update users
    set username = '$username', password = '$password', level='$level'
    WHERE id='$update_id' ";
    $connect->query($update_query);
    $connect->close();
    header('location:manager.php');           
}
else{
    header('location:manager.php');
}
?>
