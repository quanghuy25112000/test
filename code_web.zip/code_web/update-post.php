<?php

if($_POST['content']!=''){   
    $connect=new mysqli("localhost","root","","level2");
    mysqli_set_charset($connect, "utf8");
    if($connect->connect_error){
        var_dump($connect->connect_error);
        die();
    }
    $update_id=$_GET['update_id'];
    $iduser=$_POST['iduser'];
    $title=$_POST['title'];
    $content=$_POST['content'];
    $update_query='update posts
    SET  title="'.$title.'",  content = "'.$content.'"
    WHERE id="'.$_GET['update_id'].'" ';
    $connect->query($update_query);
    $connect->close();
    header('location:manager-post.php');           
}
else{
    header('location:manager-post.php');
}
?>
