<?php
    session_start();
    
        if($_POST['content']!=''){
            $username=$_SESSION['username'];
            $iduser=$_COOKIE['id'];
            $content=$_POST['content'];
	        $title=$_POST['title'];

            // $referer = $_SERVER['HTTP_REFERER'];
            // if($referer!='http://192.168.229.130:8080/index.php'){
            //     echo "<script type='text/javascript'>alert('nope');</script>";
            //     echo "<script>window.location.href='index.php';</script>";
            //     return;
            // }
            
                $connect=new mysqli("localhost","root","","level2");
                mysqli_set_charset($connect, "utf8");
                if($connect->connect_error){
                    var_dump($connect->connect_error);
                    die();
                }
                
                
                
                
                $query="insert into posts(title,content,iduser) values('$title','$content','$iduser')";
                $connect->query($query);
                
                echo $referer;
                echo "<script type='text/javascript'>alert('Đăng bafi thành công');</script>";
                echo "<script>window.location.href='index.php';</script>";
                
                $connect->close();
            
        }
        else{
            echo "<script type='text/javascript'>alert('Ko dc để trống');</script>";
        }
    

?>
