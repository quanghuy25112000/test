<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/post.css">
    <title>Document</title>
    
</head>
<body>
    <header class="sticky-top">
        <nav class="navbar navbar-expand-sm navbar-light sticky">
            <div class="container-fluid">
                
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">Home</a>
                        </li>
                        <?php 
                            session_start();
                            if(!empty($_COOKIE['id'])){
				                if($_COOKIE['level']==2){
                                echo '<li class="nav-item">
                                        <a class="nav-link active" href="manager.php">Manager</a>
                                    </li>';
				                }
                                   echo ' <li class="nav-item">
                                        <a class="nav-link " href="manager-post.php">Manager post</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link " href="logout.php">Logout</a>
                                    </li>
                                    
                                    ';
                            }
                            else{
                                echo '<li class="nav-item">
                                        <a class="nav-link " href="login.php">Login</a>
                                    </li>';
                            }

                        ?>
                        
                        

                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="text-center">
            <?php 
                $file=$_GET['file'];
                echo nl2br(file_get_contents( $file ));
                // echo "<img src='$file' alt='lllll'>";
            ?>
           
        </div>
        <div class="text-center">
           
        </div>
    </main>
    <footer>
  </textarea>
    </footer>
</body>
</html>
