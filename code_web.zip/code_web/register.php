<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <title>Document</title>
</head>

<body>
    
    <div class="container">
        <form method="POST" action="register.php" id="form">
            <div class="form-group">
                <label for="name">Username</label>
                <input type="text" class="form-control" name="username" id="name">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" id="password">
            </div>
            <div class="form-group">
                <label for="corfirm-password">Corfirm Password</label>
                <input type="password" class="form-control" name="corfirm-password" id="corfirm-password">
            </div>
            <br><br><br>
            <button type="submit">Register</button>
            <br>
            <div class="text-center">
                <a href="login.php">Login now</a>
            </div>
        </form>
    </div>


</body>

</html>
<?php
    
    if(!empty($_POST)){
        if(($_POST['username']!='') && $_POST['password']!=''){
            $username=$_POST['username'];
            
            $password=$_POST['password'];
            $connect=new mysqli("localhost","root","","level2");
            mysqli_set_charset($connect, "utf8");
            if($connect->connect_error){
                var_dump($connect->connect_error);
                die();
            }
            $query_get="select * from users where username='$username' ";
            $result=$connect->query($query_get);
            
            if ($result->num_rows > 0) {
                echo "<script type='text/javascript'>alert('Username đã tồn tại');</script>";
            }
            else{
                $query="insert into users(username,password,level) values('$username','$password',0)";
                $connect->query($query);
            echo "<script type='text/javascript'>alert('Đăng ký thành công');</script>";
            echo "<script>window.location.href='login.php';</script>";
            }
            $connect->close();
        }
        else{
            echo "<script type='text/javascript'>alert('Ko dc để trống');</script>";
        }
    }
        
    
    
?>
