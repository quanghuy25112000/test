<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <title>Document</title>
</head>

<body>
    <div class="container">
        <form method="POST" action="login.php" id="form">
            <div class="form-group">
                <label for="name">Username</label>
                <input type="text" class="form-control" name="username" id="name">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" id="password">
            </div>
            <br><br><br>
            <button type="submit">Login</button>
            <br>
            <div class="text-center">
                <a href="register.php">Register now</a>
            </div>
        </form>
    </div>


</body>

</html>
<?php
session_start();
if(!empty($_POST)){
    
    if($_POST['username']!='' && $_POST['password']!=''){
        $username=$_POST['username'];
        $password=$_POST['password'];

        $connect=new mysqli("localhost","root","","level2");
        mysqli_set_charset($connect, "utf8");
        if($connect->connect_error){
            var_dump($connect->connect_error);
            die();
        }
        $query="select * from users where  username='$username' and password='$password'";
        $result = $connect->query($query);
        if ($result->num_rows > 0) {
            while($data=$result->fetch_assoc()){
            setcookie('id', $data['id']);
	    	$_SESSION['iduser']=$data['id'];
		    $_SESSION['level']=$data['level'];
            setcookie('level', $data['level']);
		}
            //$_SESSION['username']=$username;
            echo "<script>window.location.href='./index.php';</script>";
            
        }
        else{
            echo "<script type='text/javascript'>alert('Tài khoản hoặc mật khẩu ko chính xác');</script>";
        }
        $connect->close();
        
    }
    else{
        echo "<script type='text/javascript'>alert('Tài khoản hoặc mật khẩu ko chính xác');</script>";
        
    }
}

?>




