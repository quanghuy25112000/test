<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm>

    <title>Document</title>
</head>
<body>
<header class="sticky-top">
        <nav class="navbar navbar-expand-sm navbar-light sticky">
            <div class="container-fluid">

                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">Home</a>
                        </li>
                        <?php 
                            session_start();
                            if(!empty($_COOKIE['id'])){
                                if($_COOKIE['level']==2){
                                    echo '<li class="nav-item">
                                            <a class="nav-link active" href="manager.php">Manager</a>
                                        </li>';
                                }

                                    echo '<li class="nav-item">
                                        <a class="nav-link " href="manager-post.php">Manager post</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link " href="logout.php">Logout</a>
                                    </li>
                                    
                                    ';
                            }
                            else{
                                echo '<li class="nav-item">
                                        <a class="nav-link " href="login.php">Login</a>
                                    </li>';
                            }

                        ?>

                    </ul>
                </div>
            </div>
        </nav>
    </header>
<div>

            <span>
            
            </span>
            <br>
        </div>
        <table class="table table-hover table-bordered table-striped text-center">
                <tr>
                    
		    <th>Title</th>
                    <th>Content</th>
                    <th></th>
                </tr>
                <?php
                    
                    $check=$_COOKIE['level'];
		            $c=$_COOKIE['id'];
                    $connect=new mysqli("localhost","root","","level2");
                    mysqli_set_charset($connect, "utf8");
                    if($connect->connect_error){
                        var_dump($connect->connect_error);
                        die();
                    }
                    echo '<form method="GET" >
                    <input type="text" placeholder="Title" name="title">
                    <button class="btn btn-primary">Tìm kiếm</button>
                    </form>';
                


                    if($check==2 || $check==1){
                        if(isset($_GET['title']) && $_GET['title']!=''){
                            $title=$_GET['title'];
                            $query="select * from posts where title like '%$title%'";
                        }
                        else{
                            $query="select * from posts";
                        }
                    }
                    else{
                        if(isset($_GET['title']) && $_GET['title']!=''){
                            $title=$_GET['title'];
                            $query="select * from posts where title like '%$title%' and iduser= '$c'";
                        }
                        else{
                            $query="select * from posts where iduser= '$c'";
                        }
                    }
                    
                    $result=$connect->query($query);
                    while($data = $result->fetch_assoc()) {
                       
                            echo '
                                <tr>
                                
                                <td>'.$data['title'].'</td>
                                <td style="word-wrap: break-word;">'.$data['content'].'</td>
                                <td><a href="?delete_id='.$data['id'].'"><button class="btn btn-danger">Xóa</button></a>
                                    <span><a href="?modify_id='.$data['id'].'"><button class="btn btn-primary">Chỉnh sửa</button></a></span>
                                    </td>
                                </tr>
                            ';
                        
                    }
                    if(isset($_GET['title']) && $_GET['title']!=''){
                        $data =array();
                        $res=mysqli_query($connect,$query);
                        while ($row=mysqli_fetch_array($res,1)){
                            $data[]=$row;
                        }
                        $search=($_GET['title']);
                        $count=count($data);
                        
                        echo '</br>';
                        echo "<div> '$count' result for \"'$search'\"</div>";
                    }
                    $connect->close();
                ?>
        </table>
        <div class="container">
            <?php
                $connect=new mysqli("localhost","root","","level2");
                mysqli_set_charset($connect, "utf8");
                if($connect->connect_error){
                var_dump($connect->connect_error);
                    die();
                }
                if(isset($_GET['modify_id'])){
                    $modify_id=$_GET['modify_id'];
                    $modify_query="select * from posts where id= '$modify_id'" ;
                    $result=$connect->query($modify_query);

                    while($data = $result->fetch_assoc()) {

                    echo '
                        <form  action="update-post.php?update_id='.$_GET['modify_id'].'" method="POST">
                            
			    <lable for= "title">Title</title>
			    <input type="text" class="form-control" id="title" name="title" value='.$data['title'].'>
                            <label for="passord">Content</label>
                            <input type="text" class="form-control" id="password" name="content" value="'.$data['content'].'">
			    
                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                        </form>
                        ';
                    }
                    $connect->close();
                }

                if(isset($_GET['delete_id'])){
                    $delete_id=$_GET['delete_id'];
                    $username=$_SESSION['username'];
                    $level=$_COOKIE['level'];
                    $id=$_COOKIE['id'];
                    echo $username;
                    if($level==0){
                        $connect=new mysqli("localhost","root","","level2");
                        mysqli_set_charset($connect, "utf8");
                        if($connect->connect_error){
                            var_dump($connect->connect_error);
                            die();
                        }
                        $query_get="select *from posts where id='$delete_id' and iduser= '$id'";
                        $result=$connect->query($query_get);
                        
                        if ($result->num_rows > 0) {
                            $delete_query="delete from posts where id='$delete_id'";
                            $connect->query($delete_query);
                            $connect->close();
                            echo "<script>window.location.href='manager-post.php';</script>";
                        }
                        else{
                            echo "<script type='text/javascript'>alert('Nope');</script>";

                        }
                    }
                    else{
                        $delete_query="delete from posts where id='$delete_id'";
                        $connect->query($delete_query);
                        $connect->close();
                        echo "<script>window.location.href='manager-post.php';</script>";

                    }
                   
                    
                }




            ?>

        </div>
    </div>
</body>
</html>
<?php 
    
    if(empty($_COOKIE['id'])){
        echo "<script>window.location.href='./index.php';</script>";
        
    }
?>

