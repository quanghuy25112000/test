<?php
    setcookie('id', '');
    setcookie('level','');
    echo "<script>window.location.href='./index.php';</script>";
    

?>
